//Referenciar los elementos del DOM
const nameInput = document.getElementById("nameInput");
const lastnameInput = document.getElementById("lastnameInput");
const nationalIdInput = document.getElementById("nationalIdInput");
const imageUrlInput = document.getElementById("imageUrlInput");
const createPatientButton = document.getElementById("createPatientButton");
const patientsContainer = document.getElementById("patientsContainer");

createPatientButton.addEventListener("click", createPatient);

getPatients();

let list = [];

async function getPatients() {
    let response = await fetch("http://192.168.131.186:8080/patients/all");
    list = await response.json();
    console.log(list);
    console.log(list.length);
    let content = "";
    for(let i=0 ; i<list.length ; i++){
        content += `<div id="${list[i].id}" class="card" style="width: 18rem;">
                    <img src="${list[i].imageUrl}" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">${list[i].name} ${list[i].lastname}</h5>
                        <p class="card-text">${list[i].nationalId}</p>
                        <button onclick="goToPatientSamples(${list[i].id})" class="btn btn-primary">Ver detalles</button>
                    </div>
                    </div>`;
    }
    patientsContainer.innerHTML = content;
}

function goToPatientSamples(id){
    let foundPatient;
    for(let i=0 ; i<list.length ; i++){
        if(list[i].id === id){
            foundPatient = list[i];
            break;
        }
    } // Cambiar por funcion find
    console.log(foundPatient);
    localStorage.setItem("patient", JSON.stringify(foundPatient));
    location.href = "patientSamples.html";
}


async function createPatient(event) {
    event.preventDefault();
    let newpatient = {
        name: nameInput.value,
        lastname: lastnameInput.value,
        nationalId: nationalIdInput.value,
        imageUrl: imageUrlInput.value  
    };
    let json = JSON.stringify(newpatient);
    console.log(json);

    //POST
    let response = await fetch("http://192.168.131.186:8080/patients", {
        method: "POST",
        headers: {
            "Content-Type":"application/json"
        },
        body: json
    });
    console.log(response.status);
    if(response.status === 200){
        patientsContainer.innerHTML = "La inserción fue exitosa";
        await getPatients();
    }

}