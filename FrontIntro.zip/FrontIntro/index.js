const title = document.getElementById("title");
const actionButton = document.getElementById("actionButton");
const nameInput = document.getElementById("nameInput");
const lastnameInput = document.getElementById("lastnameInput");
const nationalIdInput = document.getElementById("nationalIdInput");

actionButton.addEventListener("click", createPatient);


async function createPatient(event){
    event.preventDefault();
    console.log(nameInput.value);
    let patient = {
        name: nameInput.value,
        lastname:lastnameInput.value,
        nationalId: nationalIdInput.value
    };
    console.log(patient);
    let json = JSON.stringify(patient);
    console.log(json);

    //GET Request
    let response = await fetch("https://fakestoreapi.com/products");
    console.log(response);
    let data = await response.json();
    console.log(data);

    //GET a propia API
    let responseApi = await fetch("http://192.168.131.177:8080/hello");
    console.log(responseApi);
    let dataApi =  await responseApi.text();
    console.log(dataApi);
}

//alfa()
//alfa

function alfa(){
    console.log("Hola mundo");
    title.innerHTML = "Hola mundo Javascript";
}
function beta(){
    let a = 1; 
    let b = "Icesi";
    let c = true;

    let d = {
        name:"Esteban Gaviria",
        username:"@esteban",
        age:21,
        isSingle:true
    };

    let e = ["Mercurio", "Venus", "Tierra", "Marte"];

    console.log(a);
    console.log(b);
    console.log(c);
    console.log(d);
    console.log(e);
}

function gamma(){
    let mensaje1 = {
        message : "Hola",
        from : "@rengifo",
    };
    let mensaje2 = {
        message : "buenas",
        from : "@rengifo",
    };
    let mensaje3 = {
        message : "tardes",
        from : "@rengifo",
    };
    let array = [];
    array.push(mensaje1);
    array.push(mensaje2);
    array.push(mensaje3);
    console.log(array);
}

beta();
