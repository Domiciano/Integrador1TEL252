const url = "broker.emqx.io";
const port = Number(8083);
const username = "icesidomicianorincon123123";

const messageInput = document.getElementById('messageInput');
const sendButton = document.getElementById('sendButton');
const messageContainer = document.getElementById('messageContainer');

const client = new Paho.MQTT.Client(url, port, username);

//Callback
client.onMessageArrived = function(payload){
    console.log(payload.payloadString);
    messageContainer.innerHTML += `<p>${payload.payloadString}</p>`;
}

client.connect({
    onSuccess:function(){
        console.log("Conectado");
        client.subscribe("icesi/telematica");
    }
});

sendButton.addEventListener("click", sendMessage);

function sendMessage(){
    let msg = messageInput.value;
    let mqttPackage = new Paho.MQTT.Message(msg);
    mqttPackage.destinationName = "icesi/telematica";
    client.send(mqttPackage);
}

