  const timegraph = document.getElementById('timegraph');

let json = localStorage.getItem("sample");
let sample = JSON.parse(json);
console.log(sample);

async function getData(sampleId){
   let response = await fetch(`http://192.168.131.186:8080/data/sample/${sampleId}`);
   let data = await response.json();
   console.log(data);

   const datapoints = [
      {"ax":1, "ay":1, "az": 1},
      {"ax":2, "ay":2, "az": 2},
      {"ax":3, "ay":3, "az": 3},
   ];
   

   let series1 = datapoints.map( (point)=> ( {x:point.ax, y:point.ay} )  );
   console.log(timegraph);

    new Chart(timegraph, {
      type: 'scatter',
      data: {
        datasets: [{
          label: 'Valores t vs y',
          data: series1,
          showLine: true, 
        }]
      },
    });

}

getData(sample.id);

