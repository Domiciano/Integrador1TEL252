const patientName = document.getElementById("patientName");
const sampleContainer = document.getElementById("sampleContainer");


let patientJson = localStorage.getItem("patient");
console.log(patientJson);
let patient = JSON.parse(patientJson);
console.log(patient);

patientName.innerText = `${patient.name} ${patient.lastname}`;

getSampleByPatient(patient.id);

async function getSampleByPatient(patientId){
    let response = await fetch(`http://localhost:8080/samples/patient/${patientId}`);
    let data = await response.json();
    console.log(data);

    let output = data.map(  (sample) => `<div class="alert alert-primary" onclick="goToGraph()">Muestra #${sample.id}</div>`  );
    console.log(output);
    output.forEach( sample => sampleContainer.innerHTML += sample );
}

function goToGraph(){
    alert("Alfa");
}