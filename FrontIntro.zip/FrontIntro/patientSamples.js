const patientName = document.getElementById("patientName");
const sampleContainer = document.getElementById("sampleContainer");
let samples = [];


let patientJson = localStorage.getItem("patient");
console.log(patientJson);
let patient = JSON.parse(patientJson);
console.log(patient);

patientName.innerText = `${patient.name} ${patient.lastname}`;

getSampleByPatient(patient.id);

async function getSampleByPatient(patientId){
    let response = await fetch(`http://192.168.131.186:8080/samples/patient/${patientId}`);
    let data = await response.json();
    console.log(data);
    samples = data;

    let output = data.map(  (sample) => `<div class="alert alert-primary" onclick="goToGraph(${sample.id})">Muestra #${sample.id}</div>`  );
    console.log(output);
    output.forEach( sample => sampleContainer.innerHTML += sample );
}

function goToGraph(id){
    let foundSample = samples.find( sample => sample.id === id );
    console.log(foundSample);
    let json = JSON.stringify(foundSample);
    localStorage.setItem("sample", json);
    //location.href = "graph.html";
}