const url = "broker.emqx.io";
const port = 8083;
const username = "icesidomicianorincon123123";

const client = new Paho.MQTT.Client(url, port, username);

const students = [
  { name: "robledo", K: 1, range: [0, 5] },
  { name: "mayor", K: 2, range: [5, 10] },
  //{ name: "mosquera", K: 3, range: [10, 15] },
  { name: "barbosa", K: 4, range: [15, 20] },
  { name: "garcia", K: 5, range: [20, 25] },
  //{ name: "rengifo", K: 6, range: [25, 30] },
];

const activeGenerators = {}; // control de ON/OFF por estudiante
let t = 0; // tiempo global para seno

// ---- Interfaz dinámica ----
const grid = document.getElementById("studentsGrid");

students.forEach(s => {
  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML = `
    <h3>${s.name.toUpperCase()}</h3>
    <div class="light off" id="light-${s.name}"></div>
    <div class="data" id="data-${s.name}">Voltaje: -- | Corriente: --<br><b>JSON para hacer el ON</b><br><small>{"action":"ON","deviceId":"${s.name}"}</small><br><b>JSON para hacer el OFF</b><br><small>{"action":"OFF","deviceId":"${s.name}"}</small></div>
    
  `;
  grid.appendChild(card);
});

// ---- Conexión MQTT ----
client.onConnectionLost = () => console.log("Conexión perdida");
client.onMessageArrived = handleIncoming;

client.connect({
  onSuccess: () => {
    console.log("✅ Conectado al broker EMQX");
    client.subscribe("icesi/sensors/control");
  },
  useSSL: false
});

// ---- Manejo de mensajes ----
function handleIncoming(message) {
  try {
    const data = JSON.parse(message.payloadString);
    console.log("Mensaje recibido:", data);

    const { action, deviceId } = data;

    if (action === "ON") startGenerator(deviceId);
    if (action === "OFF") stopGenerator(deviceId);
  } catch (err) {
    console.error("Error procesando mensaje:", err);
  }
}

// ---- Enviar control (ON/OFF) ----
function sendControl(deviceId, action) {
  const msg = new Paho.MQTT.Message(JSON.stringify({ action, deviceId }));
  msg.destinationName = "icesi/sensors/control";
  client.send(msg);
}

// ---- Generador de datos ----
function startGenerator(deviceId) {
  const student = students.find(s => s.name === deviceId);
  if (!student) return;

  if (activeGenerators[deviceId]) return; // ya activo

  const light = document.getElementById(`light-${deviceId}`);
  light.classList.remove("off");
  light.classList.add("on");

  console.log(`🟢 Iniciando flujo para ${deviceId}`);

  const interval = setInterval(() => {
    t += 1;
    const voltaje = 120 * Math.sin(2 * Math.PI * 0.1 * t) + student.K;
    const corriente = randomInRange(student.range[0], student.range[1]);

    // Mostrar en tablero
    const dataDiv = document.getElementById(`data-${deviceId}`);
    dataDiv.innerText = `Voltaje: ${voltaje.toFixed(2)} | Corriente: ${corriente.toFixed(2)}`;

    // Publicar en tópico del estudiante
    const mqttPackage = new Paho.MQTT.Message(JSON.stringify({
      deviceId,
      voltaje,
      corriente,
      timestamp: new Date().toISOString()
    }));
    mqttPackage.destinationName = `icesi/sensors/${deviceId}`;
    client.send(mqttPackage);

  }, 1000);

  activeGenerators[deviceId] = interval;
}

function stopGenerator(deviceId) {
  const light = document.getElementById(`light-${deviceId}`);
  light.classList.remove("on");
  light.classList.add("off");

  if (activeGenerators[deviceId]) {
    clearInterval(activeGenerators[deviceId]);
    delete activeGenerators[deviceId];
  }

  const dataDiv = document.getElementById(`data-${deviceId}`);
  dataDiv.innerHTML = "Voltaje: -- | Corriente: --";

  console.log(`🔴 Deteniendo flujo para ${deviceId}`);
}

// ---- Utilidad ----
function randomInRange(min, max) {
  return Math.random() * (max - min) + min;
}
